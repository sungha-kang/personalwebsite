from django.urls import path
from . import views
import article

urlpatterns = [
    path('register/', views.register),
    path('login/', views.login),
    path('logout/', views.logout),
    path('article/subject/', article.views.subject),
    path('', views.home),
]