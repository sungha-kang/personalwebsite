from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password
from .models import Member
from article.models import Article

from article.views import *

def register(request) :
    if request.method == "GET":
        return render(request, 'register/register.html')

    elif request.method == "POST":
        print(request)
        print('method.POST 안의 내용 : ', request.POST)
        print('method.POST 에서 id만 추출 : ', request.POST['memberID'])

        memberID = request.POST['memberID']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        name = request.POST['username']
        email = request.POST['exampleInputEmail1']
        # check_id = Member.objects.get(memberID = memberID)
        # sql에서 select memberID from MEMBER where memberID = '{memberID}'; 이거랑 같은 의미
        subject1 = request.POST['subject1']
        subject2 = request.POST['subject2']
        
        try : 
            check_id = Member.objects.get(memberID=memberID)
        except :
            check_id = False
        
        data_dic = {}
        
        if not(memberID and password1 and password2 and name and email) :
            data_dic["err"] = "모든 값을 입력해 주세요."            
        
        elif password1 != password2:
            data_dic["err"] = "비밀번호가 일치하지 않습니다."

        elif check_id :
            print(check_id)
            print(check_id.memberID)
            print(check_id.password)
            
            data_dic["err"] = "이미 등록된 아이디 입니다."   
            
        else :
            
            memberregister = Member(
                memberID = memberID,
                password = password1, 
                name  = name,
                email = email,
            )            
            
            memberregister.save()
            
            # memberregister = Member(...) memberregister.save() 안 만들고
            # Member(...).save 만 만들어도 Ok-->
        
        return render(request, 'register/register.html', data_dic)

def login(request):
    if request.method == "GET":
        return render(request, 'login/login.html')
    
    elif request.method == "POST":
        memberID = request.POST['memberID']
        password = request.POST['password']
        
        try :
            check_id = Member.objects.get(memberID=memberID)
        except :
            check_id = False
            
        data_dic = {}
        
        if not(memberID and password) :
            data_dic["err"] = "모든 값을 입력해 주세요."
            
        elif check_id == False:
            data_dic["err"] = "등록된 아이디가 없습니다."
            
        else:
            if password == check_id.password :
                request.session["user"] = check_id.memberID
                return redirect("/")
                
            else :
                data_dic["err"] = "비밀번호가 잘못되었습니다."
                
        return render(request, 'login/login.html', data_dic) 

def home(request):
    
    data_dic={}
    data_dic["user_id"] = request.session.get("user")
    
    
    
    #이용자 로그인 정보를 확인후, 이용자 정보 및 관심주제를 불러와서 쿼리
    if data_dic["user_id"]: #로그인이 되어 있다면
        data_dic["userinfo"] = Member.objects.get(memberID = data_dic["user_id"]) #그 이용자의 정보를 가져옴.
        data_dic["articles"] = Article.objects.filter(subject1 = data_dic["userinfo"].subject1)[::-1][:5]
        print(Article.objects)
        return render(request, 'home/index.html', data_dic)
    
    #이용자 정보가 없으므로 최신 논문 5개를 불러오는 쿼리 작성
    else :
        data_dic["articles"] = Article.objects.all()[::-1][:5]
        return render(request, 'home/index.html', data_dic)  

def logout(request) :
    request.session.flush()
    return redirect('/')