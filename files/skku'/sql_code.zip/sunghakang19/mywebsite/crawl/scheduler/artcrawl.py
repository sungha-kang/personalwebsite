#from django.shortcuts import render, redirect
from django.db.models import Q
from article.models import Article
from user.models import Member
import requests
from bs4 import BeautifulSoup
import time

def articlereg() :
    field_var = 'econ'  #physics, mathematics, economics ... etc : if 'all field', leave it blank
    resultSize_var = 50  #int, 50, 100, ..., 2000 available

    url = f"https://arxiv.org/list/{field_var}/recent/pastweek?show={resultSize_var}"
    response = requests.get(url)
    
    
    if response.status_code == 200 :
        html = response.text
        soup = BeautifulSoup(html, 'html.parser')
        
        links=[link.find('a')['href'] for link in soup.find_all('span', {'class':'list-identifier'})]
        links = [link for link in links[::-1]] #[::-1] = 맨 끝에서부터 봐줘
        
        chunks = soup.find_all('div', {'class' : 'meta'}) #각 논문의 정보들을 논문 단위로 묶어서 스크래핑 진행
        chunks = [chunk for chunk in chunks[::-1]]
        # print(chunks)
        
        for paper in chunks:
            link = f"https://arxiv.org{links[chunks.index(paper)]}"  # 각 논문 상세 페이지로 연결되는 링크
            index = links[chunks.index(paper)] # 식별 위해 arxiv에서 제공한 index를 저장
        
            # 1. subjects
            subjects_tmp = paper.find('div', {'class':'list-subjects'}).get_text()
            subjects_tmp=subjects_tmp.replace('\n','')
            subjects_tmp=subjects_tmp.replace('Subjects:', '')
            subjects_tmp=subjects_tmp.strip()
        
            subjects_tmp = [subjects.split(' (')[0] for subjects in subjects_tmp.split('; ')]
            #pprint(subjects_tmp)
            
            econ_subjects = ['Econometrics', 'Theoretical Economics', 'General Economics']
            # 보통 경제학의 주제 가장 앞 (main subject)에 위치하나, main subjects 아닐 경우 이후로 가장
            for subject in subjects_tmp:
                if subject in econ_subjects:
                    #print(f"{econ_subjects.index(subject)}번째에서 {subject}를 찾았고, 이는 econ_subjects에 해당합니다.\n\n")
                    subject1 = subject
                    #print(f"{subject}는 subject1에 해당합니다.\n\n")
                    subjects_tmp.remove(subject1) #전체 subjects list에서 subjects1을 제외한 subjects list를 subjects2로 지정
                    break
                
            #pprint(f"{subject1}이 제외된 리스트는 다음과 같습니다: {subjects_tmp}")
            if len(subjects_tmp) > 0 : #subjects_tmp에서 economics subjects를 제외하고도 남아있는 경우
                subject2 = subjects_tmp[0] #economics subjects 제외하고 가장 먼저 등장한 subjects
            else :
                subject2 = ''
        
        
            # 2. title
            title = paper.find('div', {'class' : 'list-title mathjax'}).get_text()
            title = title.replace('\n', '')
            title = title.replace('Title :', '')
            title = title.strip()
            #print(f"TITLE : {title}")
    
            # 3. authors
            authors = paper.find('div', {'class' : 'list-authors'}).get_text()
            authors = authors.replace('/n', '')
            authors = authors.replace('Authors :', '')
            authors = authors.strip()
            #print(f"AUTHORS : {authors}")
            if( len(authors) >= 200):
                print("error: author name length")
                continue
    
            #4. others(reference, comments etc.)
            comment = [item.get_text() for item in paper.find_all('div', {'class' : 'list-comments mathjax'})]
            reference = [item.get_text() for item in paper.find_all('div', {'class' : 'list-journal-ref'})]
            others = comment + reference
            others = '; ' .join(others)
            others = others.replace('\n', '')
            #print(f"OTHERS : {others}")
    
            # 5. 6. 7.
            response = requests.get(link) #논문의 상세페이지로 연결
            if response.status_code == 200 :
                html = response.text
                soup = BeautifulSoup(html, 'html.parser')
                #print(soup)
        
                # 5. doi
                doi = soup.find('td', {'class' : 'tablecell arxivdoi'})
                doi = doi.find('a').get_text()
                #print(f"DOI: {doi}")
    
                # 6. abstract
                abstract = soup.find('blockquote', {'class' : 'abstract mathjax'}).get_text()
                abstract = abstract.replace('\n', '')
                abstract = abstract.replace('Abstract :', '')
                abstract = abstract.strip()
                #pprint(f"ABSTRACT : {abstract}")
            
                # 7. date
                date = soup.find('div', {'class' : 'dateline'}).get_text()
                date = date.replace('\n', '')
                #print(f"DATE : {date}")
                # arxiv 사이트에 submitted date가 기준인데, published date 기준으로 입력/정렬되도록 장고 구성하기. 기말
        
            articleregister = Article(
                index = index,
                link = link,
                doi = doi,
                subject1 = subject1,
                subject2 = subject2,
                title = title,
                author = authors,
                abstract = abstract,
                date = date,
                etc = others,
            )
            print("article saved")
            
            articleregister.save()
            time.sleep(0.1) #튕겨나가는 거 방지
    